from django.contrib import admin
from basicapp.models import UserProfileInfo

# Register your models here.
admin.site.register(UserProfileInfo)
