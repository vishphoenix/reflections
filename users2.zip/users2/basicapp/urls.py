from django.urls import path,include
from rest_framework.routers import DefaultRouter

from basicapp import views


app_name = 'basicapp'


router = DefaultRouter()
router.register('Users',views.UserProfileViewSet)
router.register('profile',views.UserProfileFeedViewSet)

urlpatterns = [
    path('login/',views.UserLoginApiView.as_view()),
    path('',include(router.urls))
]
