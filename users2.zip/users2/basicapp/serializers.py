from rest_framework import serializers
from basicapp import models

class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.UserProfile
        fields = ('id','name','email','mobile','password','dob','created_at','modified_at')



        extra_kwargs = { 'password':{
        'write_only': True,
        'style':{'input_type':'password'}
        }}

    def create(self, validated_data):
        ##create and return new user##
        user = models.UserProfile.objects.create_user(
        email = validated_data['email'],
        name=validated_data['name'],
        password=validated_data['password'],
        mobile=validated_data['mobile'],
        dob=validated_data['dob']
        )
        return user


class ProfileFeedItemSerializer(serializers.ModelSerializer):
    ##serializer feed##

    class Meta:
        model = models.ProfileFeedItem
        fields = ('id', 'user_profile','status_text','created_on')
        extra_kwargs = {'user_profile':{'read_only':True}}
