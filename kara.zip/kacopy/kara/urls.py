from django.urls import path
from django.contrib import admin
from kara import views

app_name = 'kara'

urlpatterns = [
    path("",views.index,name="index"),
    path("addAlbum/",views.addAlbum, name="addAlbum"),
    path("album/<str:id>/",views.album, name="album"),
    path("search", views.search, name="search"),
    path("addSong/<str:id>/",views.addSong, name="addSong"),
    path("karaoe/",views.karaoe,name="karaoe"),
    path('file/',views.file,name='record_file'),
    path('files/',views.files,name='record_file'),
    path('record/',views.record,name="record"),
    path('kara/',views.kara,name="kara"),
    path('kara_songs/',views.kara_songs,name="kara"),

]
