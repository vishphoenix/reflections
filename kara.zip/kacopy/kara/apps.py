from django.apps import AppConfig


class KaraConfig(AppConfig):
    name = 'kara'
