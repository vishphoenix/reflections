from django.shortcuts import render,redirect, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse, JsonResponse
from django.core.files.storage import FileSystemStorage
from django.urls import reverse
from .models import *
from django.conf import settings
from pydub import AudioSegment
from django.db.models import Q
import os,sys, stat

# Create your views here.
def index(request):
    albums = Album.objects.filter()
    return render(request, 'kara/index.html', {'albums':albums})

def addAlbum(request):
    if request.method == "POST":
        title = request.POST.get('title')
        artist = request.POST.get('artist')
        genre = request.POST.get('genre')

        logo = request.FILES['logo']
        fs = FileSystemStorage()
        filename_logo = fs.save(logo.name, logo)
        uploaded_logo_url = fs.url(filename_logo)

        album = Album.objects.create(title=title, artist=artist, genre=genre, logo=logo)
        album.save()

        return redirect('kara:index')
    else:
        return render(request, 'kara/addAlbum.html')

def album(request, id):
    album = Album.objects.get(id=id)
    songs = Song.objects.filter(album=album)
    return render(request, 'kara/album.html', {'album':album, 'songs':songs})


def addSong(request, id):
    if request.method == "POST":
        title = request.POST.get('title')
        album = Album.objects.get(id=id)

        audio = request.FILES['audio']
        fs = FileSystemStorage()
        filename_audio = fs.save(audio.name, audio)
        uploaded_audio_url = fs.url(filename_audio)

        song = Song.objects.create(title=title, audio=audio, album=album)
        song.save()

        return redirect('/album/'+id)
    else:
        return redirect('/album/'+id)

def search(request):
    if request.method == "GET":
        searchText = request.GET.get('search')
        print(searchText)
        albums = Album.objects.filter()
        songResults = Song.objects.filter(Q(title__icontains=searchText))
        albumResults = Album.objects.filter(Q(title__icontains=searchText) | Q(artist__icontains=searchText) | Q(genre__icontains=searchText))
        searchCount = songResults.count() + albumResults.count()
        return render(request, 'search.html', {'albums':albums, 'songResults':songResults, 'albumResults':albumResults, 'searchCount':searchCount})

def karaoe(request):
    return render(request,"kara/karaoe.html")

def record(request):
    return render(request,"kara/record.html")


ls = []
@csrf_exempt
def file(request):
    if request.method == 'POST' and request.FILES['audio_data']:
        myfile = request.FILES['audio_data']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        ls.append(uploaded_file_url)
        print(uploaded_file_url)
        print(type(uploaded_file_url))
        return HttpResponse("file uploaded")
    return HttpResponse("something went wrong")

@csrf_exempt
def files(request):
    ls.clear()
    if request.method == 'POST':
        print("half &**************************************")
        data=request.POST['song']
        print(data)
        ls.append(data)
        return HttpResponse("success it is") 



def kara(request):
    print(f"ls is {ls}")
    l1,l2 = ls
    # print(ls)
    l1 = os.path.join(settings.MEDIA_ROOT,l1)
    l2 = os.path.join(settings.MEDIA_ROOT,l2)
    os.chmod(l1, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)
    os.chmod(l2, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)
    l2 = AudioSegment.from_file(l2)
    l1 = AudioSegment.from_file(l1)
    combined = l2.overlay(l1)
    combined.export("karaoes/filia.mp3", format='mp3')
    return HttpResponse("conversion done as final.mp3")


def kara_songs(request):
    # files = []
    # r=root, d=directories, f = files
    files = os.listdir('kara_songs/')
    print(files)
    return render(request,'kara/kara_songs.html',{"files":files})