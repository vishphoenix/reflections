# from pydub import AudioSegment

# # sound1 = AudioSegment.from_file("/media/2_mPYoHUq.mp3")
# sound2 = AudioSegment.from_file("/media/audio_bP4LWpI.wav")
# combined = sound1.overlay(sound2)

# combined.export("we.mp3", format='mp3')


# import os
# import subprocess
# from os.path import basename

# # directory containing noise files
# noiseDir = "/media/2_mPYoHUq.mp3"
# # directory containing signal files
# signalDir = "/media/audio_ocW3pZV.mp4"
# # destination directory for mixed files
# outputDir = "heyy.mp3"

# # pathsToNoise = [os.path.join(noiseDir,fn) for fn in next(os.walk(noiseDir))[2]]
# # pathsToSignal = [os.path.join(signalDir,fn) for fn in next(os.walk(signalDir))[2]]

# # for noisePath in pathsToNoise:
# #   for signalPath in pathsToSignal:
# #     outFileName = os.path.splitext(basename(noisePath))[0] + "_" + os.path.splitext(basename(signalPath))[0] + ".wav"
# #     outFilePath = os.path.join(outputDir, outFileName)
# subprocess.call(["sox", "-m", noiseDir, signalDir, outputDir])

import os
arr = os.listdir("karaoes/")
print(arr)
# return render(request,'kara/kara_songs.html',{"files":files})